import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static Scanner scanner; // Note: Do not change this line.

    /**returns true if added, else false*/

    public static boolean addMovie(String[] movieNames, double[] movieRating,
                                String[] directors, int unique_movie_count) {
        System.out.println("Enter movie name:");
        String title = scanner.nextLine();

        if (unique_movie_count >= 100) {
            System.out.println("Movies limit reached.");
            return false;
        }

        System.out.println("Enter rating:");
        double rating;
        rating = scanner.nextDouble();
        scanner.nextLine();
        if (rating < 0 || rating > 10) {
            System.out.println("Invalid rating");
            return false;
        }

        /** Check if movie already exists */

        for (int i = 0; i < unique_movie_count ;i++) {
            if (movieNames[i].equals(title)) {
                movieRating[i] = rating;
                return false;
            }
        }

        System.out.println("Enter director name:");
        String director = scanner.nextLine();
        movieNames[unique_movie_count] = title;
        movieRating[unique_movie_count] = rating;
        directors[unique_movie_count] = director;
        System.out.println("Movie " + title + " added successfully!");
        return true;
    }


    /** Displays all movies currently in the collection */

    public static void displayAllMovies(String[] movieNames, double[] movieRating,
                                        String[] directors, int unique_movie_count) {
        if (unique_movie_count == 0) {
            System.out.println("No movies are available");
            return;
        } else {
            for (int i = 0; i < unique_movie_count ;i++) {
                System.out.println("Name: " + movieNames[i] + " rating: " +
                        movieRating[i] + " director: " + directors[i]);
            }
        }
    }


    /** Displays the rating for a specific movie */
    public static void displayMovieRating(String[] movieNames, double[] movieRating,
                                          String[] directors, int unique_movie_count) {
        System.out.println("Enter movie name:");
        String movie_title = scanner.nextLine();

        for (int i = 0; i < unique_movie_count ;i++) {
            if (movieNames[i].equals(movie_title)) {
                System.out.println("Rating for " + movieNames[i] + ": " + movieRating[i]);
                return;
            }
        }
        System.out.println("No movie found with name " + movie_title);
    }


    /** Finds and displays the director with the highest average movie rating */

    public static void findBestDirector(String[] movieNames, double[] movieRating,
                                        String[] directors, int unique_movie_count) {
        if (unique_movie_count == 0) {
            System.out.println("No movies are available.");
        } else {
            String[] directors2 = new String[unique_movie_count];
            double[] ratingSums = new double[unique_movie_count];
            int[] movieCounts = new int[unique_movie_count];
            int uniqueDirectorCount = 0;

            for (int j = 0; j < unique_movie_count; j++) {
                String director = directors[j];
                boolean found = false;

                for (int i = 0; i < uniqueDirectorCount; i++) {
                    if (directors2[i].equals(director)) {
                        ratingSums[i] += movieRating[j];
                        movieCounts[i]++;
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    directors2[uniqueDirectorCount] = director;
                    ratingSums[uniqueDirectorCount] = movieRating[j];
                    movieCounts[uniqueDirectorCount] = 1;
                    uniqueDirectorCount++;
                }
            }

            String bestDirector = "";
            double highestAverage = -1.0;

            for (int i = 0; i < uniqueDirectorCount; i++) {
                double average = ratingSums[i] / movieCounts[i];
                if (average > highestAverage) {
                    highestAverage = average;
                    bestDirector = directors2[i];
                }
            }

            System.out.printf("Best director: " + bestDirector +
                    " with an average rating of: %.2f%n", highestAverage);
        }
    }
    public static void manageMovies() {
        String choice;
        int unique_movie_count = 0;
        String[] movieNames = new String[100];
        String[] directors = new String[100];
        double[] ratings = new double[100];
        System.out.println("Welcome to the Movies Management System!.");
        while(true) {
            System.out.println("1. Add a new movie");
            System.out.println("2. Display all movies");
            System.out.println("3. Display movie rating");
            System.out.println("4. Find the best director");
            System.out.println("5. Exit");
            System.out.println("Please enter your choice:");
            //////////////////
            choice = scanner.nextLine();

            /** switch case for choice*/

            switch (choice) {
                case "1":
                    if(addMovie(movieNames, ratings, directors, unique_movie_count)){
                        unique_movie_count++;
                    };
                    break;
                case "2":
                    displayAllMovies(movieNames, ratings, directors, unique_movie_count);
                    break;
                case "3":
                    displayMovieRating(movieNames, ratings, directors, unique_movie_count);
                    break;
                case "4":
                    findBestDirector(movieNames, ratings, directors, unique_movie_count);
                    break;
                case "5":
                    System.out.println("Exiting the program. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public static void main(String[] args) throws IOException {
        String path = args[0];

        scanner = new Scanner(new File(path));
        int numberOfTests = scanner.nextInt();
        scanner.nextLine();

        for (int i = 1; i <= numberOfTests; i++) {
            System.out.println("Test number " + i + " starts.");
            try {
                manageMovies();
            } catch(Exception e){
                System.out.println("Exception " + e);
            }
            System.out.println("Test number " + i + " ended.");
            System.out.println("-----------------------------------------------");
        }
        System.out.println("All tests have ended.");
    }
}